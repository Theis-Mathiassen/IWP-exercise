'use strict'
//SEE: https://javascript.info/strict-mode

console.log("Hej Med Dig!"); 



